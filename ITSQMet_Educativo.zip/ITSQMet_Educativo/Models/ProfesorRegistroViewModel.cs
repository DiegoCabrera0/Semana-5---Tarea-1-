﻿using System.ComponentModel.DataAnnotations;

namespace ITSQMet_Educativo.Models
{
    public class ProfesorRegistroViewModel
    {
        [Required]
        [EmailAddress]
        public string Email { get; set; } = string.Empty;

        [Required]
        [DataType(DataType.Password)]
        public string Password { get; set; } = string.Empty;

        [Required]
        public string Nombre { get; set; } = string.Empty;

        [Required]
        public string Materia { get; set; } = string.Empty;
    }
}
