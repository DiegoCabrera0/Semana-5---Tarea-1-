﻿using System.ComponentModel.DataAnnotations;

namespace ITSQMet_Educativo.Models
{
    public class Asistencia
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public int EstudianteId { get; set; }

        [Required]
        [Range(1, int.MaxValue, ErrorMessage = "El total de clases debe ser mayor que 0")]
        public int TotalClases { get; set; }

        [Required]
        [Range(0, int.MaxValue, ErrorMessage = "Las clases asistidas no pueden ser negativas")]
        public int ClasesAsistidas { get; set; }

        // Porcentaje de asistencia calculado automáticamente
        public double Porcentaje => TotalClases > 0 ? (double)ClasesAsistidas / TotalClases * 100 : 0;
    }
}
