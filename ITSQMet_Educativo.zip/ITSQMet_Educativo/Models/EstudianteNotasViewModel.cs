﻿namespace ITSQMet_Educativo.Models
{
    public class EstudianteNotasViewModel
    {
        public string Nombre { get; set; } = string.Empty;
        public double Promedio { get; set; }
        public double PorcentajeAsistencia { get; set; }
    }
}
