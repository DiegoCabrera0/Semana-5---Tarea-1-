﻿using System.ComponentModel.DataAnnotations;

public class Profesor
{
    [Key]
    public int Id { get; set; }

    [Required]
    public string Nombre { get; set; } = string.Empty;

    [Required]
    public string Materia { get; set; } = string.Empty;

    [Required]
    public string CodigoRegistro { get; set; } = string.Empty;
}
