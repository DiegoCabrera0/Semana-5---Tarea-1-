﻿using System.ComponentModel.DataAnnotations;

public class Analitica
{
    public int Id { get; set; }
    public int EstudianteId { get; set; }

    public double Promedio { get; set; }

    [Required]
    public string Nivel { get; set; } = string.Empty;
}
