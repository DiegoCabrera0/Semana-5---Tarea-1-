﻿namespace ITSQMet_Educativo.Models
{
    public class ProfesorDashboardViewModel
    {
        public string NombreEstudiante { get; set; } = string.Empty;
        public string Cedula { get; set; } = string.Empty;
        public double Promedio { get; set; }
        public double PorcentajeAsistencia { get; set; }
    }
}
