﻿using System.ComponentModel.DataAnnotations;

public class Estudiante
{
    [Key]
    public int Id { get; set; }

    [Required]
    public string Cedula { get; set; } = string.Empty;

    [Required]
    public string Nombre { get; set; } = string.Empty;

    [Required]
    public string Carrera { get; set; } = string.Empty;

    [Required]
    public string CodigoProfesor { get; set; } = string.Empty;
}
