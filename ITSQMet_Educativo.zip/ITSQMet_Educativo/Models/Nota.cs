﻿using System.ComponentModel.DataAnnotations;

namespace ITSQMet_Educativo.Models
{
    public class Nota
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public int EstudianteId { get; set; }

        [Required]
        [Range(0, 10, ErrorMessage = "N1 debe estar entre 0 y 10")]
        public double N1 { get; set; }

        [Required]
        [Range(0, 10, ErrorMessage = "N2 debe estar entre 0 y 10")]
        public double N2 { get; set; }

        [Required]
        [Range(0, 10, ErrorMessage = "N3 debe estar entre 0 y 10")]
        public double N3 { get; set; }

        [Required]
        [Range(0, 10, ErrorMessage = "EX debe estar entre 0 y 10")]
        public double EX { get; set; }

        // Promedio calculado automáticamente
        public double Promedio => (N1 + N2 + N3 + EX) / 4;
    }
}
