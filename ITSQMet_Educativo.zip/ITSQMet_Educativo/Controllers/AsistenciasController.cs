﻿using ITSQMet_Educativo.Data;
using ITSQMet_Educativo.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Linq;
using System.Threading.Tasks;

public class AsistenciasController : Controller
{
    private readonly ApplicationDbContext _context;

    public AsistenciasController(ApplicationDbContext context)
    {
        _context = context;
    }

    // GET: Asistencias/Ingresar
    public IActionResult Ingresar()
    {
        ViewBag.Estudiantes = _context.Estudiantes.ToList();
        return View();
    }

    // POST: Asistencias/Ingresar
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Ingresar(Asistencia model)
    {
        if (ModelState.IsValid)
        {
            _context.Asistencias.Add(model);
            await _context.SaveChangesAsync();
            TempData["Mensaje"] = "Asistencia registrada correctamente";
            return RedirectToAction("Ingresar");
        }
        ViewBag.Estudiantes = _context.Estudiantes.ToList();
        return View(model);
    }
}
