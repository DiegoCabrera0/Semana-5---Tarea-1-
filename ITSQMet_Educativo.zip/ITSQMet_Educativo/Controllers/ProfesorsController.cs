﻿using ITSQMet_Educativo.Data;
using ITSQMet_Educativo.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Linq;
using System.Threading.Tasks;

public class ProfesorsController : Controller
{
    private readonly ApplicationDbContext _context;
    private readonly UserManager<IdentityUser> _userManager;

    public ProfesorsController(ApplicationDbContext context, UserManager<IdentityUser> userManager)
    {
        _context = context;
        _userManager = userManager;
    }

    // GET: Profesores/Registrar
    public IActionResult Registrar()
    {
        return View();
    }

    // POST: Profesores/Registrar
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Registrar(ProfesorRegistroViewModel model)
    {
        if (ModelState.IsValid)
        {
            // Crear usuario en Identity
            var usuario = new IdentityUser { UserName = model.Email, Email = model.Email };
            var resultado = await _userManager.CreateAsync(usuario, model.Password);

            if (resultado.Succeeded)
            {
                // Asignar rol Profesor
                await _userManager.AddToRoleAsync(usuario, "Profesor");

                // Generar código único para estudiantes
                var codigoUnico = Guid.NewGuid().ToString().Substring(0, 6).ToUpper();

                // Guardar info del profesor
                _context.Profesores.Add(new Profesor
                {
                    Nombre = model.Nombre,
                    Materia = model.Materia,
                    CodigoRegistro = codigoUnico
                });
                await _context.SaveChangesAsync();

                TempData["CodigoProfesor"] = codigoUnico; // para mostrar al profesor
                return RedirectToAction("Index", "Home");
            }

            foreach (var error in resultado.Errors)
            {
                ModelState.AddModelError("", error.Description);
            }
        }

        return View(model);
    }
    [Authorize(Roles = "Profesor")]
    public async Task<IActionResult> Dashboard()
    {
        // Obtener usuario logueado
        var usuario = await _userManager.GetUserAsync(User);

        // Buscar profesor por Email (ajusta según cómo guardes el login)
        var profesor = _context.Profesores.FirstOrDefault(p => p.Nombre == usuario.Email);

        if (profesor == null) return NotFound();

        // Obtener estudiantes del profesor
        var estudiantes = _context.Estudiantes
            .Where(e => e.CodigoProfesor == profesor.CodigoRegistro)
            .Select(e => new ProfesorDashboardViewModel
            {
                NombreEstudiante = e.Nombre,
                Cedula = e.Cedula,
                Promedio = _context.Notas.Where(n => n.EstudianteId == e.Id).Select(n => n.Promedio).FirstOrDefault(),
                PorcentajeAsistencia = _context.Asistencias.Where(a => a.EstudianteId == e.Id).Select(a => a.Porcentaje).FirstOrDefault()
            })
            .ToList();

        return View(estudiantes);
    }
}
