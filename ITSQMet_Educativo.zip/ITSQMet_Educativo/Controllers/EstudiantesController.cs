﻿using ITSQMet_Educativo.Data;
using ITSQMet_Educativo.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization; // 🔹 Necesario para [Authorize]
using System.Linq;
using System.Threading.Tasks;

public class EstudiantesController : Controller
{
    private readonly ApplicationDbContext _context;
    private readonly UserManager<IdentityUser> _userManager;

    public EstudiantesController(ApplicationDbContext context, UserManager<IdentityUser> userManager)
    {
        _context = context;
        _userManager = userManager;
    }

    // GET: Estudiantes/Registrar
    public IActionResult Registrar()
    {
        return View();
    }

    // POST: Estudiantes/Registrar
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Registrar(EstudianteRegistroViewModel model)
    {
        if (ModelState.IsValid)
        {
            // Validar código de profesor
            var existeCodigo = _context.Profesores.Any(p => p.CodigoRegistro == model.CodigoProfesor);
            if (!existeCodigo)
            {
                ModelState.AddModelError("", "Código de profesor inválido");
                return View(model);
            }

            // Crear usuario en Identity
            var usuario = new IdentityUser { UserName = model.Email, Email = model.Email };
            var resultado = await _userManager.CreateAsync(usuario, model.Password);

            if (resultado.Succeeded)
            {
                // Asignar rol Estudiante
                await _userManager.AddToRoleAsync(usuario, "Estudiante");

                // Guardar info del estudiante
                _context.Estudiantes.Add(new Estudiante
                {
                    Nombre = model.Nombre,
                    Cedula = model.Cedula,
                    Carrera = model.Carrera,
                    CodigoProfesor = model.CodigoProfesor
                });
                await _context.SaveChangesAsync();

                return RedirectToAction("Index", "Home");
            }

            foreach (var error in resultado.Errors)
            {
                ModelState.AddModelError("", error.Description);
            }
        }

        return View(model);
    }

    // 🔹 NUEVA ACCIÓN: Mis Notas y Asistencia del estudiante
    [Authorize(Roles = "Estudiante")]
    public async Task<IActionResult> MisNotas()
    {
        // Obtener usuario logueado
        var usuario = await _userManager.GetUserAsync(User);

        // Buscar estudiante por email (suponemos que Email = Cedula)
        var estudiante = _context.Estudiantes.FirstOrDefault(e => e.Cedula == usuario.Email);

        if (estudiante == null)
            return NotFound();

        // Obtener nota y asistencia
        var nota = _context.Notas.FirstOrDefault(n => n.EstudianteId == estudiante.Id);
        var asistencia = _context.Asistencias.FirstOrDefault(a => a.EstudianteId == estudiante.Id);

        // Generar recomendaciones
        string recomendacion = "";
        if (nota != null && nota.Promedio < 7)
            recomendacion += "Tu promedio es bajo. Revisa los temas pendientes. ";
        if (asistencia != null && asistencia.Porcentaje < 75)
            recomendacion += "Tu asistencia es baja. Procura asistir más clases.";

        ViewBag.Recomendacion = recomendacion;

        // Enviar datos a la vista
        return View(new EstudianteNotasViewModel
        {
            Nombre = estudiante.Nombre,
            Promedio = nota?.Promedio ?? 0,
            PorcentajeAsistencia = asistencia?.Porcentaje ?? 0
        });
    }
}
