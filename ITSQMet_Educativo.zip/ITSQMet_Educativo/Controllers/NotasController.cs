﻿using ITSQMet_Educativo.Data;
using ITSQMet_Educativo.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;

public class NotasController : Controller
{
    private readonly ApplicationDbContext _context;

    public NotasController(ApplicationDbContext context)
    {
        _context = context;
    }

    // GET: Notas/Ingresar
    public IActionResult Ingresar()
    {
        ViewBag.Estudiantes = _context.Estudiantes.ToList();
        return View();
    }

    // POST: Notas/Ingresar
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Ingresar(Nota model)
    {
        if (ModelState.IsValid)
        {
            _context.Notas.Add(model);
            await _context.SaveChangesAsync();
            TempData["Mensaje"] = "Nota registrada correctamente";
            return RedirectToAction("Ingresar");
        }
        ViewBag.Estudiantes = _context.Estudiantes.ToList();
        return View(model);
    }
}
